"""Subprocess entry point for a change job.

Runs out-of-process because PROJ/GDAL work is unsafe on QGIS's own threads, and because a
long job must never block the UI. Speaks a line protocol on stdout:

  PLAN <tiles> <download_bytes> <width> <height>   once, before any download
  TILE <done> <total> <vrt_path>                   after each tile lands (VRT rewritten)
  AUTO <threshold> <fraction_above>                once, when finished
  ERR  <message>
  OK

Usage: python -m embed_cd.worker '<json spec>'
"""
import json
import logging
import os
import site
import sys


class _FirstProblem(logging.Handler):
    """Remembers the first warning raised during the job, so a run that produces nothing can say
    WHY. A tile that fails is logged and skipped — right for one bad tile, but when EVERY tile
    fails the only clue was in those logs, on a stderr nobody read. That is how a missing GDAL
    function on Linux surfaced as nothing more than "none landed in the output grid"."""

    def __init__(self):
        super().__init__(logging.WARNING)
        self.first = None

    def emit(self, record):
        if self.first is None:
            exc = record.exc_info[1] if record.exc_info else None
            self.first = ("%s: %s" % (type(exc).__name__, exc)) if exc else record.getMessage()


def _setup_logging():
    """Warnings and tracebacks to stderr, which the dock forwards to QGIS's Log Messages panel;
    plus the first one kept for the user-facing failure message."""
    first = _FirstProblem()
    logging.basicConfig(level=logging.WARNING, stream=sys.stderr,
                        format="%(levelname)s %(name)s: %(message)s")
    logging.getLogger().addHandler(first)
    return first


def _enable_user_site():
    """QGIS runs with the per-user site-packages OFF, and a subprocess inherits that. A
    non-admin `pip install` lands exactly there, so put it back on the path."""
    for d in filter(None, [site.getusersitepackages()] if hasattr(site, "getusersitepackages")
                    else []):
        if isinstance(d, str) and os.path.isdir(d) and d not in sys.path:
            site.addsitedir(d)


def main():
    spec = json.loads(sys.argv[1])
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    _enable_user_site()
    first_problem = _setup_logging()
    # No pre-flight reader check any more: the tile index is fetched pre-built as a .npz and read
    # with numpy, so pyarrow and the GDAL Parquet driver are only a fallback for building it from
    # the raw parquet if that hosted download is unreachable. If BOTH the download and that
    # fallback fail, `list_tiles` -> Index.load() raises, and the catch-all below prints a clear
    # message (it carries source.install_hint()). Refusing up front here instead just guaranteed
    # the hosted path never ran — which is exactly what broke on a Linux QGIS that had neither
    # reader but perfectly good network access to the index.
    from embed_cd import job, score, vrt

    out_dir = spec["out_dir"]
    name = spec.get("name", "change")
    vrt_path = os.path.join(out_dir, name + ".vrt")
    stop_file = os.path.join(out_dir, ".cancel")

    try:
        # The source must know the target resolution BEFORE listing tiles: a coarse job
        # reads an overview, and a tile then covers proportionally more ground.
        src = job.open_source(spec.get("cache_dir"), spec["res_m"])
        bbox = tuple(spec["bbox"])
        all_tiles, both, partial = job.list_tiles(src, bbox, spec["year_a"], spec["year_b"])
        if not all_tiles:
            print("ERR No AlphaEarth tiles cover this area in either year. Try a different "
                  "area.", flush=True)
            return 2
        import embed_cd.grid as G
        g = G.make_grid(bbox, spec["dst_crs"], spec["res_m"])
        est = G.estimate(g, len(both) or len(all_tiles))
        # partial tiles still produce a result (a nodata class), so report both counts
        print(f"PLAN {len(all_tiles)} {est['download_bytes']} "
              f"{g.width} {g.height} {len(partial)}", flush=True)
        if spec.get("plan_only"):
            return 0

        os.makedirs(out_dir, exist_ok=True)
        seen = []

        def on_tile(done, total, rec, hist_total):
            # A NEW file per tile, never a rewrite of the same one. QGIS caches the opened
            # dataset per layer and neither reloadData() nor setDataSource() to the same path
            # dislodges it — measured — so rewriting in place leaves the canvas showing whatever
            # revision it first opened. That is the "tiles don't appear until you zoom in and
            # out" behaviour. Only a path it has never seen forces a real reopen.
            seen.append(rec)
            rev = os.path.join(out_dir, f"{name}.v{done}.vrt")
            vrt.write_vrt(rev, g, seen)
            print(f"TILE {done} {total} {rev}", flush=True)
            older = os.path.join(out_dir, f"{name}.v{done - 1}.vrt")
            if os.path.exists(older):
                try:
                    os.remove(older)         # keep only the live one and the canonical
                except OSError:
                    pass                     # still open on Windows; the final sweep gets it

        g2, records, hist, partial = job.run(
            bbox, spec["year_a"], spec["year_b"], out_dir,
            dst_crs=spec["dst_crs"], res_m=spec["res_m"],
            cache_dir=spec.get("cache_dir"), on_tile=on_tile,
            should_stop=lambda: os.path.exists(stop_file),
            cell_m=spec.get("cell_m"),
        )
        if not records:
            # Say WHAT was tried, not just that it failed. This message used to be the entire
            # output of a failed run, and the commonest cause — an output CRS that cannot
            # express the resolution in metres, so the grid collapses to a pixel or two and
            # every tile falls outside it — was indistinguishable from a network problem.
            why = ""
            if min(g.width, g.height) < 4:
                why = (f" The {g.width}x{g.height} px output grid is too small to hold any of "
                       f"them, which happens when the output CRS ({spec['dst_crs']}) is not in "
                       f"metres — Detail is metres, so in a degrees-based CRS it is read as "
                       f"degrees.")
            elif first_problem.first:
                why = f" First error: {first_problem.first} (full detail: Log Messages > EMBED-CD)"
            print(f"ERR No tiles produced a result. {len(all_tiles)} tile(s) cover this area "
                  f"but none landed in the {g.width}x{g.height} px output grid.{why}", flush=True)
            return 2
        # The canonical name is written for the user (a stable file to reopen), but the LAYER
        # stays on the last revision — pointing it back at a path it has already opened this
        # session would resurrect the stale-dataset problem.
        vrt.write_vrt(vrt_path, g2, records)
        # Remove superseded revisions by EXACT name. A prefix test does not work here:
        # "change.vrt".startswith("change.v") is true, so matching on the prefix deletes the
        # canonical file this just wrote — which it did, until the end-to-end run caught it.
        for i in range(1, len(records)):
            stale = os.path.join(out_dir, f"{name}.v{i}.vrt")
            if os.path.exists(stale):
                try:
                    os.remove(stale)
                except OSError:
                    pass                     # still open; harmless, it is a few KB
        t = score.otsu_from_histogram(hist)
        print(f"AUTO {t:.6f} {score.fraction_above(hist, t):.6f}", flush=True)
        print("OK", flush=True)
        return 0
    except Exception as exc:                       # surface, don't traceback into the UI
        print(f"ERR {type(exc).__name__}: {exc}", flush=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
