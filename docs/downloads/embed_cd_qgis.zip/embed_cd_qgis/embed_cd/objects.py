"""Turn the change raster into objects, and give each one the embedding of what it covers.

This is the half of the design that runs AFTER the job, on files already on disk — which is what
makes the threshold free. Re-cutting at a different cutoff costs seconds and no downloads, and
that matters because objects are emphatically NOT nested across thresholds: measured, one object
at 0.015 broke into 125 separate objects at 0.05. There is no "capture once, filter later" for
geometry, so geometry is simply recomputed whenever it is asked for.

Two rules earn their keep:

* **Vectors are transformed, cell grids never are.** Cells live in the tile's native UTM; polygons
  come off the raster in the project's CRS. We move the polygon into UTM to look cells up.
  Reprojecting the cell grids instead would resample aggregates and quietly corrupt the totals.
* **Count-weighted means.** A polygon spanning tiles combines cells as
  `sum(mean_i * n_i) / sum(n_i)` — exactly the mean over its pixels. An unweighted average of
  cell means would over-weight partial edge cells.

numpy + GDAL (scipy where installed). Writing the GeoPackage is the plugin's job, using QGIS's own
vector API — the engine never imports QGIS.
"""
import os
import struct

import numpy as np

from . import cells as CE
from . import score as S

_M2_PER_HA = 10000.0
_CONNECTIVITY = 8            # matches the 3x3 structure used when the thresholds were measured


def _components(arr, mask, crs, transform):
    """(labels, n, means, maxes) for the 8-connected components of `mask`, numbered 1..n in
    raster-scan order of each component's first pixel, with per-component mean and max of `arr`.

    scipy.ndimage does this where it is installed — the Windows QGIS ships it, so there nothing
    changes. Ubuntu's QGIS packages do NOT ship scipy, and needing a pip install is exactly what
    this plugin promises not to do; so without it, GDAL finds the components instead and numpy
    takes the statistics. `test_em_objects` checks the two produce identical output.
    """
    try:
        from scipy import ndimage
    except ImportError:
        return _components_without_scipy(arr, mask, crs, transform)
    labels, n = ndimage.label(mask, structure=np.ones((3, 3)))
    if n == 0:
        return labels, 0, None, None
    idx = np.arange(1, n + 1)
    return labels, n, ndimage.mean(arr, labels, idx), ndimage.maximum(arr, labels, idx)


def _components_without_scipy(arr, mask, crs, transform):
    """ndimage.label + mean + maximum from GDAL and numpy alone, same output.

    GDAL's Polygonize with 8-connectivity traces exactly one polygon per 8-connected component
    (holes included, diagonal-only joins included). Burning those polygons back with the
    pixel-CENTRE rule recovers each component's pixels exactly, because every edge lies on a pixel
    boundary. That gives one label per component, numbered in GDAL's trace order — so they are
    then renumbered to scipy's order (first pixel in raster scan), which keeps the objects, their
    order and their row indices the same whichever path ran.
    """
    from . import gdalio as GD

    traced = GD.polygonize(mask.astype(np.int32), mask, crs, transform, _CONNECTIVITY)
    if not traced:
        return np.zeros(mask.shape, np.int32), 0, None, None
    labels = GD.rasterize_index([wkt for wkt, _ in traced], crs, mask.shape, transform,
                                all_touched=False).astype(np.int32)

    flat = labels.ravel()
    at = np.flatnonzero(flat)                       # ascending = raster-scan order
    found, first = np.unique(flat[at], return_index=True)
    remap = np.zeros(len(traced) + 1, np.int32)
    remap[found[np.argsort(first)]] = np.arange(1, len(found) + 1, dtype=np.int32)
    labels = remap[labels]
    n = len(found)

    lab = labels.ravel()
    counts = np.bincount(lab, minlength=n + 1)[1:]
    # ndimage.mean is itself a weighted bincount, so this is the same sum in the same order
    means = np.bincount(lab, weights=arr.ravel(), minlength=n + 1)[1:] / counts
    inside = np.flatnonzero(lab)
    order = inside[np.argsort(lab[inside], kind="stable")]
    starts = np.r_[0, np.flatnonzero(np.diff(lab[order])) + 1]
    maxes = np.maximum.reduceat(arr.ravel()[order], starts)
    return labels, n, means, maxes


def polygonize(vrt_path, threshold, min_area_ha=1.0):
    """[{wkt, area_ha, chg_mean, chg_max, n_px}] for connected change at or above `threshold`.

    Components are labelled first and their statistics taken from the pixels directly, so area
    and mean are exact rather than derived from the traced outline.
    """
    from . import gdalio as GD

    arr, crs, transform = GD.read(vrt_path, band=1)
    px_ha = abs(transform.a * transform.e) / _M2_PER_HA

    mask = np.isfinite(arr) & (arr != S.NODATA) & (arr >= threshold)
    if not mask.any():
        return [], crs
    labels, n, means, maxes = _components(arr, mask, crs, transform)
    if n == 0:
        return [], crs

    idx = np.arange(1, n + 1)
    counts = np.bincount(labels.ravel(), minlength=n + 1)[1:]
    keep = counts * px_ha >= min_area_ha
    if not keep.any():
        return [], crs

    wanted = set(int(v) for v in idx[keep])
    out = []
    for wkt, value in GD.polygonize(labels, mask, crs, transform, _CONNECTIVITY):
        if value not in wanted:
            continue
        out.append({"wkt": wkt,
                    "area_ha": float(counts[value - 1] * px_ha),
                    "chg_mean": float(means[value - 1]),
                    "chg_max": float(maxes[value - 1]),
                    "n_px": int(counts[value - 1])})
        wanted.discard(value)                 # one geometry per component
    return out, crs


class CellIndex:
    """The cell stores of one job, opened once and reused across every polygon."""

    def __init__(self, out_dir, year_a, year_b, cell_m=CE.CELL_M):
        # Ground metres, matching cells_filename. Naming these by PIXELS would make the same
        # 160 m cells invisible to the classifier whenever Detail changed which overview was read.
        prefix = f"cells_{year_a}-{year_b}_{cell_m:g}m_"
        self.files = sorted(os.path.join(out_dir, f) for f in os.listdir(out_dir)
                            if f.startswith(prefix) and f.endswith(".tif")) if \
            os.path.isdir(out_dir) else []
        self._loaded = None

    def __bool__(self):
        return bool(self.files)

    def load(self):
        if self._loaded is None:
            self._loaded = [CE.read_cells(p) for p in self.files]
        return self._loaded

    @property
    def depth(self):
        return self.load()[0][0].shape[2] if self.files else 0


def attach_vectors(polygons, index, src_crs, pool_cutoff=None, progress=None):
    """[N, 2*depth] float32 — each polygon's count-weighted mean embedding, year A then year B.

    `pool_cutoff` skips cells whose own mean change score is below it, trading context for
    purity. `None` uses every covered cell. A polygon the cutoff empties keeps its unfiltered
    vector rather than coming back as zeros.
    """
    from . import gdalio as GD

    grids = index.load()
    depth = index.depth
    out = np.zeros((len(polygons), 2 * depth), np.float32)
    if not grids or not polygons:
        return out

    acc = np.zeros((len(polygons), 2 * depth), np.float64)
    acc_all = np.zeros((len(polygons), 2 * depth), np.float64)
    weight = np.zeros(len(polygons))
    weight_all = np.zeros(len(polygons))

    for gi, (ma, mb, n, smean, _smax, crs, tr) in enumerate(grids):
        # ONE rasterization per cell grid, burning each polygon's 1-based index, instead of one
        # per polygon per grid. Polygons come from connected components so they never overlap.
        wkts = [GD.transform_wkt(p["wkt"], src_crs, str(crs)) for p in polygons]
        burned = GD.rasterize_index(wkts, str(crs), ma.shape[:2], tr)
        present = np.unique(burned)
        for i, poly in enumerate(polygons):
            if progress is not None and progress(gi * len(polygons) + i,
                                                len(grids) * len(polygons)) is False:
                return out
            if (i + 1) not in present:
                continue
            hit = (burned == i + 1) & (n > 0)
            if not hit.any():
                continue
            w = n[hit]
            vecs = np.concatenate([ma[hit], mb[hit]], axis=1)
            acc_all[i] += (vecs * w[:, None]).sum(axis=0)
            weight_all[i] += w.sum()
            if pool_cutoff is not None:
                keep = smean[hit] >= pool_cutoff
                if not keep.any():
                    continue
                vecs, w = vecs[keep], w[keep]
            acc[i] += (vecs * w[:, None]).sum(axis=0)
            weight[i] += w.sum()

    for i in range(len(polygons)):
        if weight[i] > 0:
            out[i] = acc[i] / weight[i]
        elif weight_all[i] > 0:
            out[i] = acc_all[i] / weight_all[i]
    return out


def pack_vec(vec):
    """float32 vector -> bytes, for the GeoPackage BLOB column."""
    v = np.asarray(vec, np.float32)
    return struct.pack(f"<{v.size}f", *v.tolist())


def unpack_vec(blob):
    return np.frombuffer(bytes(blob), dtype="<f4").astype(np.float32)
